<link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/img/favicon.png') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/fontawesome/css/fontawesome.min.css') ?>">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/plugins/fontawesome/css/all.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>"> </head>

<link rel="stylesheet" href="<?= base_url('assets/css/feathericon.min.css') ?>">
<link rel="stylesheet" href="../../../releases/v5.8.2/css/all.css"> </head>