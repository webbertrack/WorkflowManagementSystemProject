<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index(){
		$data['page'] = 'Login page';
		$this->load->view('login',$data);
	}
	public function authentication(){
		$emp_id = $this->input->post('emp_id');
		$this->load->model('loginModel');		
		if($empDetails = $this->loginModel->getEmpDetails($emp_id)) {			
			$password = $this->input->post('login[password]');
			if(password_verify($password, $empDetails['password'])) {
				$sessionArray['emp_id'] = $empDetails['emp_id'];
				$this->session->set_userdata( $sessionArray );				
				if($empDetails['user_type'] == 'user5' || $empDetails['user_type'] == 'user6') {
					redirect('analyst/analyst');
				}
			}else{
				$this->session->set_flashdata('password', 'Password is incorrect!');
				return redirect('login');
			}
		}else{
			$this->session->set_flashdata('emp_id', 'Please check your employee id!');
			return redirect('login');
			// print("Please enter the correct Employee ID.");
		}
	}

}