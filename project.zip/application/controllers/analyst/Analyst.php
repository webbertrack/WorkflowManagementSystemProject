<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Analyst extends CI_Controller {

	public function index(){
		$page = 
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));
		$this->load->view('analyst/index', $data);
	}

}