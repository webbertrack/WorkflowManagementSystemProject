<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model {

	public function getEmpDetails($emp_id){
		$this->db->where(['emp_id'=>$emp_id, 'status'=>1]);
		$result = $this->db->get('emp_details')->row_array();
		if($result){
			return $result;
		}else{
			return false;
		}
		// echo $this->db->last_query();
		// exit();
	}
}