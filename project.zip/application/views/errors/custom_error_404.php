<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>Trelix WMS | Page not found page</title>
		<?php require 'assets/css.php' ?> 
	</head>
	<body class="error-page">
		<div class="main-wrapper">
			<div class="error-box">
				<h1>404</h1>
				<h3 class="h2 mb-3"><i class="fas fa-exclamation-triangle"></i> Oops! Page not found!</h3>
				<p class="h4 font-weight-normal">The page you requested was not found.</p>
				<a href="" class="btn btn-primary">Back to Home</a>
			</div>
		</div>
		<?php require 'assets/js.php' ?>
	</body>
</html>